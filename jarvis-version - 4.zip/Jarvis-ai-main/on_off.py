# import os
# import pyttsx3
# import speech_recognition as sr
# import platform
# from ctypes import cast, POINTER
# from comtypes import CLSCTX_ALL
# from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

# # Initialize text-to-speech
# engine = pyttsx3.init()

# def speak(text):
#     """Speak the given text."""
#     engine.say(text)
#     engine.runAndWait()

# def listen_command():
#     """Listen to the user's voice command."""
#     recognizer = sr.Recognizer()
#     with sr.Microphone() as source:
#         speak("I am listening for your command sir.")
#         print("Listening...")
#         audio = recognizer.listen(source)
#         try:
#             command = recognizer.recognize_google(audio).lower()
#             print(f"You said: {command}")
#             return command
#         except sr.UnknownValueError:
#             speak("Sorry, I didn't catch that. Please repeat.")
#             return ""
#         except sr.RequestError:
#             speak("Network error. Please try again later.")
#             return ""

# def control_wifi(command):
#     """Turn Wi-Fi on or off."""
#     if platform.system() == "Windows":
#         if "on" in command:
#             os.system("netsh interface set interface Wi-Fi enabled")
#             speak("Wi-Fi turned on.")
#         elif "off" in command:
#             os.system("netsh interface set interface Wi-Fi disabled")
#             speak("Wi-Fi turned off.")
#     else:
#         speak("Wi-Fi control is not supported on this OS.")

# def control_bluetooth(command):
#     """Turn Bluetooth on or off."""
#     if platform.system() == "Windows":
#         if "on" in command:
#             os.system("Start Bluetooth")
#             speak("Bluetooth turned on.")
#         elif "off" in command:
#             os.system("Stop Bluetooth")
#             speak("Bluetooth turned off.")
#     else:
#         speak("Bluetooth control is not supported on this OS.")

# def adjust_brightness(command):
#     """Adjust screen brightness."""
#     if platform.system() == "Windows":
#         from screen_brightness_control import set_brightness, get_brightness
#         current_brightness = get_brightness()[0]
#         if "increase" in command:
#             new_brightness = min(current_brightness + 25, 100)
#             set_brightness(new_brightness)
#             speak(f"Brightness increased to {new_brightness}%.")
#         elif "decrease" in command:
#             new_brightness = max(current_brightness - 25, 0)
#             set_brightness(new_brightness)
#             speak(f"Brightness decreased to {new_brightness}%.")
#     else:
#         speak("Brightness control is not supported on this OS.")

# # def adjust_volume(command):
# #     """Adjust system volume."""
# #     devices = AudioUtilities.GetSpeakers()
# #     interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
# #     volume = cast(interface, POINTER(IAudioEndpointVolume))
# #     current_volume = volume.GetMasterVolumeLevelScalar() * 100
# #     if "increase" in command:
# #         new_volume = min(current_volume + 25, 100) / 100
# #         volume.SetMasterVolumeLevelScalar(new_volume, None)
# #         speak(f"Volume increased to {int(new_volume * 100)}%.")
# #     elif "decrease" in command:
# #         new_volume = max(current_volume - 25, 0) / 100
# #         volume.SetMasterVolumeLevelScalar(new_volume, None)
# #         speak(f"Volume decreased to {int(new_volume * 100)}%.")



# def speak(text):
#     # Placeholder for the speak function implementation
#     print(text)

# def adjust_volume(command):
#     """Adjust system volume."""
#     devices = AudioUtilities.GetSpeakers()
#     interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
#     volume = cast(interface, POINTER(IAudioEndpointVolume))

#     if "mute" in command:
#         volume.SetMute(1, None)  # Mute the audio
#         speak("System muted sir.")
#     elif "unmute" in command:
#         volume.SetMute(0, None)  # Unmute the audio
#         speak("System unmuted sir.")
#     else:
#         current_volume = volume.GetMasterVolumeLevelScalar() * 100

#         if "increase volume" in command or "increasevolume" in command:
#             new_volume = min(current_volume + 25, 100) / 100
#             volume.SetMasterVolumeLevelScalar(new_volume, None)
#             speak(f"Volume increased to {int(new_volume * 100)}%.")
#         elif "decrease volume" in command or "decreasevolume" in command:
#             new_volume = max(current_volume - 25, 0) / 100
#             volume.SetMasterVolumeLevelScalar(new_volume, None)
#             speak(f"Volume decreased to {int(new_volume * 100)}%.")






# def process_command(command):
#     """Process the command to control features."""
#     if "wifi" in command:
#         control_wifi(command)
#     elif "bluetooth" in command:
#         control_bluetooth(command)
#     elif "brightness" in command:
#         adjust_brightness(command)
#     elif "volume" in command:
#         adjust_volume(command)
#     else:
#         speak("Sorry, I didn't understand the command.")


#***************************************************************************************************************



import os
import pyttsx3
import speech_recognition as sr
import platform
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

# Initialize text-to-speech
engine = pyttsx3.init()

def speak(text):
    """Speak the given text."""
    engine.say(text)
    engine.runAndWait()

def listen_command():
    """Listen to the user's voice command."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        speak("I am listening for your command sir.")
        print("Listening...")
        audio = recognizer.listen(source)
        try:
            command = recognizer.recognize_google(audio).lower()
            print(f"You said: {command}")
            return command
        except sr.UnknownValueError:
            speak("Sorry, I didn't catch that. Please repeat.")
            return ""
        except sr.RequestError:
            speak("Network error. Please try again later.")
            return ""

def control_wifi(command):
    """Turn Wi-Fi on or off."""
    if platform.system() == "Windows":
        if "on" in command:
            os.system("netsh interface set interface Wi-Fi enabled")
            speak("Wi-Fi turned on.")
        elif "off" in command:
            os.system("netsh interface set interface Wi-Fi disabled")
            speak("Wi-Fi turned off.")
    else:
        speak("Wi-Fi control is not supported on this OS.")

def control_bluetooth(command):
    """Turn Bluetooth on or off."""
    if platform.system() == "Windows":
        if "on" in command:
            os.system("Start Bluetooth")
            speak("Bluetooth turned on.")
        elif "off" in command:
            os.system("Stop Bluetooth")
            speak("Bluetooth turned off.")
    else:
        speak("Bluetooth control is not supported on this OS.")

def adjust_brightness(command):                                                 # working
    """Adjust screen brightness."""
    if platform.system() == "Windows":
        from screen_brightness_control import set_brightness, get_brightness
        current_brightness = get_brightness()[0]
        if "increase brightness" in command:
            new_brightness = min(current_brightness + 25, 100)
            set_brightness(new_brightness)
            speak(f"Brightness increased to {new_brightness}%.")
        elif "decrease brightness" in command:
            new_brightness = max(current_brightness - 25, 0)
            set_brightness(new_brightness)
            speak(f"Brightness decreased to {new_brightness}%.")
    else:
        speak("Brightness control is not supported on this OS.")


def adjust_volume(command):                     # working
    """Adjust system volume."""
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    volume = cast(interface, POINTER(IAudioEndpointVolume))

    if "no sound" in command:                         # not working
        volume.SetMute(1, None)  # Mute the audio
        speak("System muted.")
    elif "sound" in command:                      # not working
        volume.SetMute(0, None)  # Unmute the audio
        speak("System unmuted.")
    elif "maximum volume" in command:
        volume.SetMasterVolumeLevelScalar(1.0, None)  # Set volume to 100%
        speak("Volume set to maximum, 100%.")
    else:
        current_volume = volume.GetMasterVolumeLevelScalar() * 100
        if "increase volume" in command or "increasevolume" in command:
            new_volume = min(current_volume + 25, 100) / 100
            volume.SetMasterVolumeLevelScalar(new_volume, None)
            speak(f"Volume increased to {int(new_volume * 100)}%.")
        elif "decrease volume" in command or "decreasevolume" in command:
            new_volume = max(current_volume - 25, 0) / 100
            volume.SetMasterVolumeLevelScalar(new_volume, None)
            speak(f"Volume decreased to {int(new_volume * 100)}%.")


import winreg

def control_night_light(command):
    """Turn Night Light mode on or off."""
    if platform.system() == "Windows":
        try:
            # Open the registry key
            key_path = r"Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache\DefaultAccount"
            registry = winreg.ConnectRegistry(None, winreg.HKEY_CURRENT_USER)
            key = winreg.OpenKey(registry, key_path, 0, winreg.KEY_WRITE)

            # Set the Night Light state
            if "on" in command:
                data = b'\x02\x00\x00\x00'  # Binary data to enable Night Light
                winreg.SetValueEx(key, "$$windows.data.bluelightreduction.bluelightreductionstate", 0, winreg.REG_BINARY, data)
                speak("Night Light mode turned on.")
            elif "off" in command:
                data = b'\x01\x00\x00\x00'  # Binary data to disable Night Light
                winreg.SetValueEx(key, "$$windows.data.bluelightreduction.bluelightreductionstate", 0, winreg.REG_BINARY, data)
                speak("Night Light mode turned off.")

            winreg.CloseKey(key)
        except Exception as e:
            speak(f"Failed to change Night Light mode: {e}")
    else:
        speak("Night Light mode control is not supported on this OS.")


def process_command(command):
    """Process the command to control features."""
    if "wifi" in command:
        control_wifi(command)
    elif "bluetooth" in command:
        control_bluetooth(command)
    elif "brightness" in command:
        adjust_brightness(command)
    elif "volume" in command:
        adjust_volume(command)
    elif "night light" in command:
        control_night_light(command)
    else:
        speak("Sorry, I didn't understand the command.")














################################ volume $ brightness working  ######################




# import os
# import pyttsx3
# import speech_recognition as sr
# import platform
# from ctypes import cast, POINTER
# from comtypes import CLSCTX_ALL
# from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

# # Initialize text-to-speech
# engine = pyttsx3.init()

# def speak(text):
#     """Speak the given text."""
#     engine.say(text)
#     engine.runAndWait()

# def listen_command():
#     """Listen to the user's voice command."""
#     recognizer = sr.Recognizer()
#     with sr.Microphone() as source:
#         speak("I am listening for your command.")
#         print("Listening...")
#         audio = recognizer.listen(source)
#         try:
#             command = recognizer.recognize_google(audio).lower()
#             print(f"You said: {command}")
#             return command
#         except sr.UnknownValueError:
#             speak("Sorry, I didn't catch that. Please repeat.")
#             return ""
#         except sr.RequestError:
#             speak("Network error. Please try again later.")
#             return ""

# def control_wifi(command):
#     """Turn Wi-Fi on or off."""
#     if platform.system() == "Windows":
#         if "on" in command:
#             os.system("netsh interface set interface name=\"Wi-Fi\" admin=enabled")
#             speak("Wi-Fi turned on.")
#         elif "off" in command:
#             os.system("netsh interface set interface name=\"Wi-Fi\" admin=disabled")
#             speak("Wi-Fi turned off.")
#     else:
#         speak("Wi-Fi control is not supported on this OS.")

# def control_bluetooth(command):
#     """Turn Bluetooth on or off."""
#     if platform.system() == "Windows":
#         if "on" in command:
#             os.system("powershell Start-Service bthserv")
#             speak("Bluetooth turned on.")
#         elif "off" in command:
#             os.system("powershell Stop-Service bthserv")
#             speak("Bluetooth turned off.")
#     else:
#         speak("Bluetooth control is not supported on this OS.")


# def adjust_brightness(command):
#     """Adjust screen brightness."""
#     if platform.system() == "Windows":
#         from screen_brightness_control import set_brightness, get_brightness
#         current_brightness = get_brightness()[0]
#         if "increase" in command:
#             new_brightness = min(current_brightness + 25, 100)
#             set_brightness(new_brightness)
#             speak(f"Brightness increased to {new_brightness}%.")
#         elif "decrease" in command:
#             new_brightness = max(current_brightness - 25, 0)
#             set_brightness(new_brightness)
#             speak(f"Brightness decreased to {new_brightness}%.")
#     else:
#         speak("Brightness control is not supported on this OS.")

# def adjust_volume(command):
#     """Adjust system volume."""
#     devices = AudioUtilities.GetSpeakers()
#     interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
#     volume = cast(interface, POINTER(IAudioEndpointVolume))
#     current_volume = volume.GetMasterVolumeLevelScalar() * 100
#     if "increase" in command:
#         new_volume = min(current_volume + 25, 100) / 100
#         volume.SetMasterVolumeLevelScalar(new_volume, None)
#         speak(f"Volume increased to {int(new_volume * 100)}%.")
#     elif "decrease" in command:
#         new_volume = max(current_volume - 25, 0) / 100
#         volume.SetMasterVolumeLevelScalar(new_volume, None)
#         speak(f"Volume decreased to {int(new_volume * 100)}%.")


# def process_command(command):
#     """Process the command to control features."""
#     if "wifi" in command:
#         control_wifi(command)
#     elif "bluetooth" in command:
#         control_bluetooth(command)
#     elif "brightness" in command:
#         adjust_brightness(command)
#     elif "volume" in command:
#         adjust_volume(command)
#     else:
#         speak("Sorry, I didn't understand the command.")

# if __name__ == "__main__":
#     while True:
#         command = listen_command()
#         if "exit" in command or "quit" in command:
#             speak("Goodbye!")
#             break
#         process_command(command)
