# import speech_recognition as sr
# import os
# import webbrowser
# import pyttsx3

# # Initialize Text-to-Speech Engine
# engine = pyttsx3.init()

# def speak(text):
#     """Speak the given text."""
#     engine.say(text)
#     engine.runAndWait()

# def open_app(command):
#     """Open the app or fallback to browser if app is not found."""
#     if "kmplayer" in command:
#         speak("Opening KMPlayer")
#         try:
#             os.system("start kmplayer")  # For Windows, adjust for your OS if needed
#         except:
#             webbrowser.open("https://www.kmplayer.com")  # Fallback to KMPlayer website
#     elif "settings" in command:
#         speak("Opening Settings")
#         try:
#             os.system("start ms-settings:")  # For Windows
#         except:
#             webbrowser.open("https://www.microsoft.com/en-us/windows/get-windows-10")  # Fallback to Windows settings page

#     elif "speed.exe" in command:
#         speak("Opening need for speed game")
#         try:
#             os.system("")  # For Windows
#         except:
#             webbrowser.open("https://www.google.com/search?q=notepad")  # Fallback to search for Notepad



#     elif "notepad" in command:
#         speak("Opening Notepad")
#         try:
#             os.system("start notepad")  # For Windows
#         except:
#             webbrowser.open("https://www.google.com/search?q=notepad")  # Fallback to search for Notepad
#     else:
#         speak(f"I didn't recognize the app, searching for {command}")
#         print("App not recognized! Searching in browser...")
#         webbrowser.open(f"https://www.google.com/search?q={command}")
        
  
# # Recognize Voice Command
# recognizer = sr.Recognizer()
# with sr.Microphone() as source:
#     speak("I am listening for your command.")
#     print("Listening...")
#     audio = recognizer.listen(source)
#     try:
#         command = recognizer.recognize_google(audio).lower()
#         speak(f"You said {command}")
#         open_app(command)
#     except sr.UnknownValueError:
#         speak("Sorry, I couldn't understand that.")
#         print("Sorry, I couldn't understand that.")

#*********************************************only setting working**************************************

import os
import webbrowser
import pyttsx3

# Initialize Text-to-Speech Engine
engine = pyttsx3.init()

def speak(text):
    """Speak the given text."""
    engine.say(text)
    engine.runAndWait()

def open_kmplayer():
    """Open KMPlayer."""
    speak("Opening KMPlayer.")
    try:
        os.system("start kmplayer")
    except:
        webbrowser.open("https://www.kmplayer.com")

def open_settings():
    """Open system settings."""
    speak("Opening Settings.")
    try:
        os.system("start ms-settings:")
    except:
        webbrowser.open("https://www.microsoft.com/en-us/windows/get-windows-10")

def open_notepad():
    """Open Notepad."""
    speak("Opening Notepad.")
    try:
        os.system("start notepad")
    except:
        webbrowser.open("https://www.google.com/search?q=notepad")

def open_instagram():
    """Open Instagram."""
    speak("Opening Instagram.")
    webbrowser.open("https://www.instagram.com")

def open_facebook():
    """Open Facebook."""
    speak("Opening Facebook.")
    webbrowser.open("https://www.facebook.com")

def open_whatsapp():
    """Open WhatsApp."""
    speak("Opening WhatsApp.")
    webbrowser.open("https://web.whatsapp.com")

def open_youtube():
    """Open YouTube."""
    speak("Opening YouTube.")
    webbrowser.open("https://www.youtube.com")

def open_gmail():
    """Open Gmail."""
    speak("Opening Gmail.")
    webbrowser.open("https://mail.google.com")

def open_spotify():
    """Open Spotify."""
    speak("Opening Spotify.")
    webbrowser.open("https://open.spotify.com")

def open_twitter():
    """Open Twitter."""
    speak("Opening Twitter.")
    webbrowser.open("https://twitter.com")

def open_discord():
    """Open Discord."""
    speak("Opening Discord.")
    webbrowser.open("https://discord.com")

def open_app(command):
    """Open apps based on the given command."""
    if "kmplayer" in command:
        open_kmplayer()
    elif "settings" in command:
        open_settings()
    elif "notepad" in command:
        open_notepad()
    elif "instagram" in command:
        open_instagram()
    elif "facebook" in command:
        open_facebook()
    elif "whatsapp" in command:
        open_whatsapp()
    elif "youtube" in command:
        open_youtube()
    elif "gmail" in command:
        open_gmail()
    elif "spotify" in command:
        open_spotify()
    elif "twitter" in command:
        open_twitter()
    elif "discord" in command:
        open_discord()
    else:
        speak("Sorry, I couldn't recognize that app.")
