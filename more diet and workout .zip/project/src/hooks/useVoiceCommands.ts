import { useEffect, useCallback } from 'react';

export function useVoiceCommands(commands: {
  onStart?: () => void;
  onNext?: () => void;
  onPause?: () => void;
  onResume?: () => void;
  onStop?: () => void;
}) {
  const recognition = 'webkitSpeechRecognition' in window
    ? new (window as any).webkitSpeechRecognition()
    : null;

  const processCommand = useCallback((transcript: string) => {
    const command = transcript.toLowerCase().trim();

    switch (command) {
      case 'start workout':
      case 'begin':
        commands.onStart?.();
        break;
      case 'next':
      case 'next exercise':
        commands.onNext?.();
        break;
      case 'pause':
      case 'pause workout':
        commands.onPause?.();
        break;
      case 'resume':
      case 'continue':
        commands.onResume?.();
        break;
      case 'stop':
      case 'end workout':
        commands.onStop?.();
        break;
    }
  }, [commands]);

  useEffect(() => {
    if (!recognition) {
      console.log('Speech recognition not supported');
      return;
    }

    recognition.continuous = true;
    recognition.interimResults = false;

    recognition.onresult = (event: any) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          processCommand(event.results[i][0].transcript);
        }
      }
    };

    recognition.start();

    return () => {
      recognition.stop();
    };
  }, [recognition, processCommand]);

  return {
    isSupported: !!recognition,
  };
}