import React from 'react';
import { Play, Clock, BarChart, Dumbbell, Filter, X, Mic, Volume2 } from 'lucide-react';
import { workoutPlans } from '../data/workouts';
import { WorkoutPlan } from '../types/user';
import { cn } from '../lib/utils';
import { useVoiceCommands } from '../hooks/useVoiceCommands';

export function Workouts() {
  const [selectedWorkout, setSelectedWorkout] = React.useState<WorkoutPlan | null>(null);
  const [selectedCategory, setSelectedCategory] = React.useState<string>('All');
  const [selectedDifficulty, setSelectedDifficulty] = React.useState<string>('All');
  const [activeExercise, setActiveExercise] = React.useState<number>(0);
  const [isWorkoutActive, setIsWorkoutActive] = React.useState(false);
  const [timer, setTimer] = React.useState<number>(0);
  const [isResting, setIsResting] = React.useState(false);
  const [isPaused, setIsPaused] = React.useState(false);

  const categories = ['All', 'Full Body', 'Arms', 'Legs', 'Core', 'Custom'];
  const difficulties = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  const filteredWorkouts = workoutPlans.filter(workout => {
    const categoryMatch = selectedCategory === 'All' || workout.category === selectedCategory;
    const difficultyMatch = selectedDifficulty === 'All' || workout.difficulty === selectedDifficulty;
    return categoryMatch && difficultyMatch;
  });

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
  };

  const startWorkout = () => {
    setIsWorkoutActive(true);
    setActiveExercise(0);
    setTimer(0);
    setIsPaused(false);
    if (selectedWorkout) {
      speak(`Starting ${selectedWorkout.title}. First exercise: ${selectedWorkout.exercises[0].name}`);
    }
  };

  const pauseWorkout = () => {
    setIsPaused(true);
    speak('Workout paused');
  };

  const resumeWorkout = () => {
    setIsPaused(false);
    speak('Workout resumed');
  };

  const stopWorkout = () => {
    setIsWorkoutActive(false);
    setSelectedWorkout(null);
    setActiveExercise(0);
    speak('Workout ended');
  };

  const nextExercise = () => {
    if (selectedWorkout) {
      if (activeExercise < selectedWorkout.exercises.length - 1) {
        setActiveExercise(prev => prev + 1);
        setIsResting(true);
        setTimer(selectedWorkout.exercises[activeExercise].restTime);
        speak(`Rest for ${selectedWorkout.exercises[activeExercise].restTime} seconds`);
      } else {
        stopWorkout();
        speak('Congratulations! You have completed your workout.');
      }
    }
  };

  React.useEffect(() => {
    let interval: number | undefined;
    if (isWorkoutActive && timer > 0 && !isPaused) {
      interval = window.setInterval(() => {
        setTimer(prev => {
          if (prev <= 1) {
            setIsResting(false);
            if (selectedWorkout) {
              speak(`Next exercise: ${selectedWorkout.exercises[activeExercise].name}`);
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isWorkoutActive, timer, isPaused, selectedWorkout, activeExercise]);

  const { isSupported } = useVoiceCommands({
    onStart: () => !isWorkoutActive && selectedWorkout && startWorkout(),
    onNext: () => isWorkoutActive && !isResting && nextExercise(),
    onPause: () => isWorkoutActive && !isPaused && pauseWorkout(),
    onResume: () => isWorkoutActive && isPaused && resumeWorkout(),
    onStop: () => isWorkoutActive && stopWorkout(),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Workout Plans</h1>
        <div className="flex items-center space-x-4">
          {isSupported && (
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
              <Mic className="h-4 w-4" />
              <span>Voice Commands Active</span>
            </div>
          )}
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSelectedDifficulty('All');
            }}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700"
          >
            <Filter className="h-5 w-5" />
            <span>Clear Filters</span>
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-4 mb-6">
        <div className="space-y-2">
          <label className="text-sm font-medium">Category</label>
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={cn(
                  "px-4 py-2 rounded-lg transition-colors",
                  selectedCategory === category
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700"
                )}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Difficulty</label>
          <div className="flex flex-wrap gap-2">
            {difficulties.map(difficulty => (
              <button
                key={difficulty}
                onClick={() => setSelectedDifficulty(difficulty)}
                className={cn(
                  "px-4 py-2 rounded-lg transition-colors",
                  selectedDifficulty === difficulty
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700"
                )}
              >
                {difficulty}
              </button>
            ))}
          </div>
        </div>
      </div>

      {selectedWorkout && isWorkoutActive ? (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold">{selectedWorkout.title}</h2>
            <div className="flex items-center space-x-4">
              {isSupported && (
                <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                  <Volume2 className="h-4 w-4" />
                  <span>Voice Guidance On</span>
                </div>
              )}
              <button
                onClick={stopWorkout}
                className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
          </div>

          <div className="space-y-6">
            {isResting ? (
              <div className="text-center py-8">
                <h3 className="text-2xl font-bold mb-4">Rest Time</h3>
                <div className="text-4xl font-bold text-blue-600">{timer}s</div>
                <p className="mt-4 text-gray-600 dark:text-gray-400">
                  Get ready for the next exercise
                </p>
              </div>
            ) : (
              <>
                <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-4">
                    {selectedWorkout.exercises[activeExercise].name}
                  </h3>
                  {selectedWorkout.exercises[activeExercise].gifUrl && (
                    <img
                      src={selectedWorkout.exercises[activeExercise].gifUrl}
                      alt={selectedWorkout.exercises[activeExercise].name}
                      className="w-full h-64 object-cover rounded-lg mb-4"
                    />
                  )}
                  <div className="space-y-2">
                    {selectedWorkout.exercises[activeExercise].instructions?.map((instruction, i) => (
                      <div key={i} className="flex items-center space-x-2">
                        <div className="w-2 h-2 rounded-full bg-blue-600" />
                        <span>{instruction}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                    <span>{selectedWorkout.exercises[activeExercise].sets} sets</span>
                    <span>{selectedWorkout.exercises[activeExercise].reps} reps</span>
                    <span>{selectedWorkout.exercises[activeExercise].restTime}s rest</span>
                  </div>
                </div>

                <div className="flex space-x-4">
                  {isPaused ? (
                    <button
                      onClick={resumeWorkout}
                      className="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg flex items-center justify-center space-x-2 hover:bg-green-700 transition-colors"
                    >
                      <Play className="h-5 w-5" />
                      <span>Resume</span>
                    </button>
                  ) : (
                    <button
                      onClick={pauseWorkout}
                      className="flex-1 bg-yellow-600 text-white py-3 px-4 rounded-lg flex items-center justify-center space-x-2 hover:bg-yellow-700 transition-colors"
                    >
                      <span>Pause</span>
                    </button>
                  )}
                  <button
                    onClick={nextExercise}
                    className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors"
                  >
                    <Play className="h-5 w-5" />
                    <span>Next Exercise</span>
                  </button>
                </div>
              </>
            )}

            <div className="mt-4 flex justify-between text-sm text-gray-600 dark:text-gray-400">
              <span>Exercise {activeExercise + 1} of {selectedWorkout.exercises.length}</span>
              <span>{Math.round((activeExercise / selectedWorkout.exercises.length) * 100)}% Complete</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredWorkouts.map((workout) => (
            <div key={workout.id} className="rounded-lg overflow-hidden bg-white dark:bg-gray-800 shadow-lg">
              <img
                src={workout.image}
                alt={workout.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-xl font-semibold mb-2">{workout.title}</h3>
                <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400 mb-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {workout.duration}
                  </div>
                  <div className="flex items-center">
                    <BarChart className="h-4 w-4 mr-1" />
                    {workout.difficulty}
                  </div>
                  <div className="flex items-center">
                    <Dumbbell className="h-4 w-4 mr-1" />
                    {workout.category}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setSelectedWorkout(workout);
                    startWorkout();
                  }}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors"
                >
                  <Play className="h-4 w-4" />
                  <span>Start Workout</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}