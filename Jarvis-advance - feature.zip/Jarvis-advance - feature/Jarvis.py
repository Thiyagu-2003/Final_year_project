from sqlite3 import Date
import pyttsx3  # pip install pyttsx3
import speech_recognition as sr  # pip install speechRecognition
import datetime
import wikipedia  # pip install wikipedia
import webbrowser
import pywhatkit
import pyjokes
import os
import wolframalpha
from requests import get
import sys
import requests
from bs4 import BeautifulSoup
from playsound import playsound
from pywikihow import search_wikihow
from keyboard import press, press_and_release
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QTimer, QTime, QDate, Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtWidgets import QMainWindow, QApplication
from sympy import sympify, SympifyError
from jarvisUi import Ui_jarvisUi
from YT import YouTubeAuto
import wikipediaapi
from WindowsAuto import WindowsAuto
from internet_speed_test import check_internet_speed
from Features import My_Location
from Features import GoogleMaps
from Features import listen
from Features import Temp
from app_handler import open_app
#from on_off import speak, listen_command, control_wifi, control_bluetooth, adjust_brightness, adjust_volume
from on_off import process_command
import pyautogui


# Initialize pyttsx3 engine
engine = pyttsx3.init()
engine.setProperty('rate', 175)
engine.setProperty('voice', engine.getProperty('voices')[0].id)

def speak(text):
    """Speak the given text."""
    engine.say(text)
    engine.runAndWait()

def listen_command():
    """Listen for a voice command from the user."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for command...")
        speak("Listening for command.")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
    
    try:
        command = recognizer.recognize_google(audio,language='en-in').lower()
        print(f"You said: {command}\n")
        return command
    except sr.UnknownValueError:
        speak("Sorry, I couldn't understand that.")
        return ""
    except sr.RequestError:
        speak("Sorry, there was an issue with the speech recognition service.")
        return ""
command=listen_command().lower
    

# Initialize pyttsx3 engine for voice
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)
engine.setProperty('rate', 175)


# Speak function
def speak(audio):
    engine.say(audio)
    engine.runAndWait()


# Startup
def startup():
    speak("All systems have been activated.")


    #***************************************************** new *******************************************************

# WolframAlpha computational intelligence
def computational_intelligence(question):
    try:
        client = wolframalpha.Client('4H2PW2-3JYYGVHJQ6')  # Add your WolframAlpha API Key
        answer = client.query(question)
        answer = next(answer.results).text
        print(answer)
        return answer
    except:
        speak("Sorry sir, I couldn't fetch the answer. Please try again.")
        return None


# Wish the user
def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        print("Good morning sir!")
        speak("Good morning sir!")
    elif hour >= 12 and hour < 17:
        print("Good afternoon sir!")
        speak("Good afternoon sir!")
    elif hour >= 12 and hour < 17:
        print("Good evening sir!")
        speak("Good evening sir!")
    else:
        print("Good night sir!")
        speak("Good night sir!")
    speak("Please tell me how may I help you.")

   # WIKIPEDIA FUNCTION

def tell_me_about(self):
    try:
        # Removing the trigger phrase
        speak('Searching Wikipedia...please wait')
        self.query = self.query.replace("tell me about", "").strip()
        print(f"Query: {self.query}")

        # Searching for the topic
        results = wikipedia.summary(self.query, sentences=2)
        
        # Speaking the result
        speak("According to wikipedia...")
        print(results)
        speak(results)

    except wikipedia.DisambiguationError as e:
        # Handle multiple results found for the query
        speak("There are multiple topics matching your query. Please be more specific.")
        print(f"DisambiguationError: {e.options}")

    except wikipedia.PageError:
        # Handle the case where no results are found
        speak("Sorry, I could not find any information on Wikipedia for that topic.")
        print("PageError: No results found for the query.")

    except Exception as e:
        # Catch all other exceptions
        speak("Sorry, an error occurred while searching Wikipedia.")
        print(f"Error: {e}")




# Main Task Execution Class
class MainThread(QtCore.QThread):
    def __init__(self):
        super(MainThread, self).__init__()

    def run(self):
        self.TaskExecution()

    def takeCommand(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            r.pause_threshold = 1
            audio = r.listen(source, 0, 4)

        try:
            print("Recognizing...")
            self.query = r.recognize_google(audio, language='en-us')
            print(f"User said: {self.query}\n")
        except Exception as e:
            print("Say that again please...")

            return "None"
        return self.query

    def TaskExecution(self):
        startup()
        wishMe()
        while True:
            self.query = self.takeCommand().lower()

       
            if 'tell me about' in self.query:
                tell_me_about(self)

            #    speak('Searching Wikipedia...please wait')
            #    self.query = self.query.replace("tell me about", "").strip()
            #    results = wikipedia.summary(self.query, sentences=2)
            #    speak("Internet says...")
            #    print(results)
            #    speak(results)

            elif 'open youtube' in self.query:
                webbrowser.open("youtube.com")

            elif "calculate" in self.query or "what is" in self.query or "multiply" in self.query or "times" in self.query:
                try:
                    question = self.query.replace("calculate", "").replace("what is", "").replace("multiply", "").replace("times", "").strip()
                    expression = sympify(question)
                    result = expression.evalf()

                    if float(result).is_integer():
                        answer = int(result)
                    else:
                        answer = round(float(result), 6)
                    print(f"The answer is {answer}")
                    speak(f"The answer is {answer}")
                except SympifyError:
                    speak("I couldn't understand the mathematical expression. Please try again.")
                except Exception as e:
                    speak("An error occurred while performing the calculation. Please try again.")

            elif 'play' in self.query:
                speak('Surfing the browser.... Hold on sir')
                self.query = self.query.replace('play', '')
                speak('Playing' + self.query)
                speak('Enjoy the music')
                pywhatkit.playonyt(self.query)

            elif any(keyword in self.query for keyword in ['pause', 'resume', 'mute', 'unmute', 'next', 'previous', 'increase', 'decrease', 'back', 'skip', 'fullscreen', 'filmscreen', 'volume up', 'volume down', 'max volume']):
                command = self.query
                YouTubeAuto(command)
                speak(f"Performing the {command} action.")

            elif 'joke' in self.query:
                speak(pyjokes.get_joke())

            elif 'ip address' in self.query:
                ip = get("https://api.ipify.org").text
                speak(f'Your current IP address is {ip}')

            elif 'time' in self.query or 'date' in self.query:
                now = datetime.datetime.now()
                if 'time' in self.query:
                    current_time = now.strftime("%I:%M %p")
                    speak(f"The current time is {current_time}")
                if 'date' in self.query:
                    current_date = now.strftime("%A, %B %d, %Y")
                    speak(f"Today's date is {current_date}")


            elif 'where is' in self.query.lower():
                Place = self.query.lower().replace('where is', '').replace('cortana', '').strip()
                if not Place:
                    speak("I couldn't understand the location. Please try again.")
                else:
                    speak(f"Searching for {Place} on Google Maps.")
                    # Open Google Maps with the specific query
                    import webbrowser
                    webbrowser.open(f"https://www.google.com/maps/search/{Place}")

            elif 'open google' in self.query:
                webbrowser.open("google.com")

            
            elif 'current temperature' in self.query:
                search = "temperature in my current location"
                url = f"https://www.google.com/search?q={search}"
                r = requests.get(url)
                data = BeautifulSoup(r.text, "html.parser")
                temp = data.find("div", class_="BNeawe").text
                speak(f'The current temperature in your location is {temp}')


            elif 'windows' in self.query or any(keyword in self.query for keyword in ['home screen', 'minimize', 'show start', 'open setting','open search', 'screen shot', 'restore windows','start recording', 'stop recording']):
                WindowsAuto(self.query)


                # adding new features

            elif "internet speed" in self.query: #working
                check_internet_speed()

            elif 'my location' in self.query: #working
                My_Location() 


            elif 'show location' in self.query or 'find location' in self.query:
                try:
                    # Ask the user for the place name using speech
                    speak("Please tell me the name of the place.")
                    place = listen() # Use the listen function for speech-based input
        
                    if place:
                        speak(f"Searching for {place} on Google Maps.")
                        GoogleMaps(place)  # Call the GoogleMaps function with the place name
                    else:
                        speak("I couldn't hear the place name. Please try again.")
                except Exception as e:
                        print(f"Error occurred: {e}")
                        speak("Sorry, I couldn't fetch the location. Please try again.")

            # elif 'open app' in self.query:
            #     speak("Which app would you like me to open?")
            #     app_name = listen_command()  # Capture app name from user
            #     open_app(app_name)

            # elif  'open app' in self.query:
            #     speak("Which app would you like me to open?")
            #     app_name = listen_command()  # Capture app name from user
            #     call_function(app_name)


            elif "hello" in self.query:
                speak('Hello sir , Good to see you')
                speak('How may i help You?')

            elif 'wifi' in self.query or 'bluetooth' in self.query or 'brightness' in self.query or 'volume' in self.query:
                process_command(self.query)

            elif 'type' in self.query:
                speak("please tell me what should i write")
                while True:
                    writeInNotepad=command()
                    if writeInNotepad=='exit typing':
                        speak("Done sir")
                    else:
                        pyautogui.write(writeInNotepad)
        

            elif "what can you do for me" in self.query:
                speak('Yes sir,Nice Question')
                speak('As per my program,I\'m a virtual assiatant which can perform tasks through your voice cammand')
            
            elif "cool" in self.query or "nice" in self.query or "awsome" in self.query or "thank you" in self.query:
                speak("Yes sir,That's my pleasure!")





            elif 'shutup' in self.query or 'exit program' in self.query or 'exit' in self.query:
                speak("Shutting down. Goodbye, sir.")
                sys.exit()


# Main Class for GUI
class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_jarvisUi()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.startTask)
        self.ui.pushButton_2.clicked.connect(self.close)

    def __del__(self):
        sys.stdout = sys.__stdout__

    def startTask(self):
        self.ui.movie = QtGui.QMovie(".\\Material/new.gif")
        self.ui.label_2.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie(".\\Material/path.gif")
        self.ui.label_3.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie(".\\Material/logo.gif")
        self.ui.label_5.setMovie(self.ui.movie)
        self.ui.movie.start()
        timer = QTimer(self)
        timer.timeout.connect(self.showTime)
        timer.start(1000)
        startExecution.start()

    def showTime(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        label_time = current_time.toString('hh:mm:ss')
        label_date = current_date.toString(Qt.ISODate)
        self.ui.textBrowser.setText(label_date)
        self.ui.textBrowser_2.setText(label_time)


startExecution = MainThread()

# Start the Application
app = QApplication(sys.argv)
jarvis = Main()
jarvis.show()
exit(app.exec_())
