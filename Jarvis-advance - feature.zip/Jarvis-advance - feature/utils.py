# Shared utility functions like GoogleMap
def GoogleMap(location):
    import webbrowser
    url = f"https://www.google.com/maps/place/{location.strip().replace(' ', '+')}"
    webbrowser.open(url)
