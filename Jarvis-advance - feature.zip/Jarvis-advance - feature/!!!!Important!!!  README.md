# Jarvis-AI
Functions performed by the AI :

-google search
-play videos on youtube
-search your location
-check the current temperature
-check your ip address
-check your Wi-fi speed
-provide you news from NASA
-open any files in computer
-hotword detection
-calculate 
-search the map
-gives answer to every question
-chatbot
-personal assistant
-screenshot
-wikipedia search
-tutorial of almost everthing
-play a rock, paper , scissors game with you
