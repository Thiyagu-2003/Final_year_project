# from pyautogui import press, keyDown, keyUp
# import pyttsx3 


# # Initialize pyttsx3 engine
# engine = pyttsx3.init()
# engine.setProperty('rate', 175)  # Set speaking speed
# engine.setProperty('voice', engine.getProperty('voices')[1].id)  # Set female voice (optional)

# def speak(text):
#     """Speak the given text."""
#     engine.say(text)
#     engine.runAndWait()

# def press_and_release(key_combination):
#     """Simulates pressing and releasing a key combination."""
#     keys = key_combination.split('+')  # Split keys by '+'
#     for key in keys:
#         keyDown(key.strip())  # Press each key
#     for key in reversed(keys):
#         keyUp(key.strip())  # Release each key

# def WindowsAuto(command):
#     query = str(command).lower()

#     if 'home screen' in query:
#         speak("Minimizing all windows and showing the home screen.")
#         press_and_release('win+m')

#     elif 'minimize' in query:
#         speak("Minimizing all windows.")
#         press_and_release('win+m')

#     elif 'show start' in query:
#         speak("Opening the start menu.")
#         press('win')

#     elif 'open setting' in query:
#         speak("Opening the settings window.")
#         press_and_release('win+i')

#     elif 'open search' in query:
#         speak("Opening the search bar.")
#         press_and_release('win+s')

#     elif 'screenshot' in query:
#         speak("Taking a screenshot.")
#         press_and_release('win+shift+s')

#     elif 'restore windows' in query:
#         speak("Restoring all minimized windows.")
#         press_and_release('win+shift+m')

#     elif 'start recording' in query:
#         speak("Starting screen recording.")
#         press_and_release('win+alt+r')

#     elif 'stop recording' in query:
#         speak("Stopping screen recording.")
#         press_and_release('win+alt+r')
#     else:
#         speak("Sorry, I didn't understand the command.")

#********************************************** for voice feedback ****************************************************
#________________________________________________all working except screen shot___________________________________________

# import pyttsx3  # For voice feedback
# from pyautogui import press, keyDown, keyUp
# import pyautogui

# # Initialize pyttsx3 engine
# engine = pyttsx3.init()
# engine.setProperty('rate', 175)  # Set speaking speed
# engine.setProperty('voice', engine.getProperty('voices')[1].id)  # Set female voice (optional)

# def speak(text):
#     """Speak the given text."""
#     engine.say(text)
#     engine.runAndWait()

# def press_and_release(key_combination):
#     """Simulates pressing and releasing a key combination."""
#     keys = key_combination.split('+')  # Split keys by '+'
#     for key in keys:
#         keyDown(key.strip())  # Press each key
#     for key in reversed(keys):
#         keyUp(key.strip())  # Release each key

# def take_screenshot():
#     """Take a screenshot by triggering the Snipping Tool."""
#     try:
#         speak("Taking a screenshot. Please select the area.")
#         press_and_release('win+shift+s')  # Windows Snipping Tool shortcut
#         speak("Screenshot taken.")
#     except Exception as e:
#         speak("Failed to take a screenshot.")
#         print(f"Error: {e}")


# def WindowsAuto(command):
#     query = str(command).lower()

#     if 'home screen' in query:
#         speak("Minimizing all windows and showing the home screen.")
#         press_and_release('win+m')

#     elif 'minimize' in query:
#         speak("Minimizing all windows.")
#         press_and_release('win+m')

#     elif 'show start' in query:
#         speak("Opening the start menu.")
#         press('win')

#     elif 'open setting' in query:
#         speak("Opening the settings window.")
#         press_and_release('win+i')

#     elif 'open search' in query:
#         speak("Opening the search bar.")
#         press_and_release('win+s')

#     elif 'screenshot' in query or 'screen shot' in query:
#         # speak("Taking a screenshot. Please select the area.")
#         # Use Snipping Tool
#         # press_and_release('win+shift+s')
#         take_screenshot()


#     elif 'restore windows' in query:
#         speak("Restoring all minimized windows.")
#         press_and_release('win+shift+m')

#     elif 'start recording' in query:
#         speak("Starting screen recording.")
#         press_and_release('win+alt+r')

#     elif 'stop recording' in query:
#         speak("Stopping screen recording.")
#         press_and_release('win+alt+r')

#     else:
#         speak("Sorry, I didn't understand the command.")


#********************************************** for advance voice feedback ****************************************************


# from keyboard import press, press_and_release
# import pyautogui
# import time
# import pyttsx3
# import os

# # Initialize pyttsx3 engine
# engine = pyttsx3.init()
# engine.setProperty('rate', 175)
# engine.setProperty('voice', engine.getProperty('voices')[1].id)


# def speak(text):
#     """Speak the given text."""
#     engine.say(text)
#     engine.runAndWait()

# def press_and_release(key_combination):
#     """Simulate pressing and releasing a key combination."""
#     try:
#         keys = key_combination.split('+')
#         for key in keys:
#             print(f"Pressing {key.strip()}")  # Debug log
#             pyautogui.keyDown(key.strip())
#         for key in reversed(keys):
#             print(f"Releasing {key.strip()}")  # Debug log
#             pyautogui.keyUp(key.strip())
#     except Exception as e:
#         speak(f"Error pressing keys: {key_combination}")
#         print(f"Error: {e}")

# def take_screenshot():
#     """Take a screenshot and save it to the current directory."""
#     try:
#         speak("Taking a screenshot.")
#         screenshot_path = os.path.join(os.getcwd(), "screenshot.png")
#         screenshot = pyautogui.screenshot()
#         screenshot.save(screenshot_path)
#         #speak(f"Screenshot saved as {screenshot_path}.")
#         print(f"Screenshot saved at: {screenshot_path}")
#     except Exception as e:
#         speak("Failed to take a screenshot.")
#         print(f"Error: {e}")

# # Simulate voice command
# query = "screenshot"
# if 'screenshot' in query or 'screen shot' in query:
#     take_screenshot()

# def start_screen_recording():
#     """Simulate starting screen recording using Xbox Game Bar."""
#     try:
#         speak("Starting screen recording.")
#         press_and_release('win+alt+r')  # Xbox Game Bar shortcut
#         time.sleep(2)  # Allow time for recording to start
#         speak("Screen recording has started.")
#     except Exception as e:
#         speak("Failed to start screen recording.")
#         print(f"Error: {e}")

# def stop_screen_recording():
#     """Simulate stopping screen recording using Xbox Game Bar."""
#     try:
#         speak("Stopping screen recording.")
#         press_and_release('win+alt+r')  # Xbox Game Bar shortcut
#         time.sleep(2)  # Allow time for recording to stop
#         speak("Screen recording has stopped.")
#     except Exception as e:
#         speak("Failed to stop screen recording.")
#         print(f"Error: {e}")



# def WindowsAuto(command):
#     query = str(command).lower()

#     if 'home screen' in query:
#         speak("Minimizing all windows and showing the home screen.")
#         press_and_release('win+m')

#     elif 'minimize' in query:
#         speak("Minimizing all windows.")
#         press_and_release('win+m')

#     elif 'show start' in query:
#         speak("Opening the start menu.")
#         press('win')

#     elif 'open setting' in query:
#         speak("Opening the settings window.")
#         press_and_release('win+i')

#     elif 'open search' in query:
#         speak("Opening the search bar.")
#         press_and_release('win+s')

#     elif 'screen shot' in query or 'screenshot' in query:
#         take_screenshot()

#     elif 'restore windows' in query:
#         speak("Restoring all minimized windows.")
#         press_and_release('win+shift+m')

#     elif 'start recording' in query:
#         start_screen_recording()

#     elif 'stop recording' in query:
#         stop_screen_recording()

#     else:
#         speak("Sorry, I didn't understand the command.")




#********************************************** for voice feedback working*********************************************
from pyautogui import press, keyDown, keyUp, screenshot
import pyttsx3
import os
import datetime
import pyautogui


# Initialize pyttsx3 engine
engine = pyttsx3.init()
engine.setProperty('rate', 175)  # Set speaking speed
engine.setProperty('voice', engine.getProperty('voices')[0].id)  # Set female voice (optional)

def speak(text):
    """Speak the given text."""
    engine.say(text)
    engine.runAndWait()

def press_and_release(key_combination):
    """Simulates pressing and releasing a key combination."""
    keys = key_combination.split('+')  # Split keys by '+'
    for key in keys:
        keyDown(key.strip())  # Press each key
    for key in reversed(keys):
        keyUp(key.strip())  # Release each key

def WindowsAuto(command):
    query = str(command).lower()

    if 'home screen' in query:
        speak("Minimizing all windows and showing the home screen sir.")
        press_and_release('win+m')

    elif 'minimize' in query or 'minimise' in query:
        speak("Minimizing windows sir.")
        # press_and_release('win+m')
        pyautogui.hotkey('win','down','down')

    elif 'maximize' in query or 'maximise' in query:
        speak("Maximizing windows sir.")
        # press_and_release('win+m')
        pyautogui.hotkey('win','up','up')

    elif 'close the window' in query or 'close the application' in query:
        speak("closing sir.")
        pyautogui.hotkey('ctrl','w')

    elif 'take a screenshot' in query:
        speak("Taking a screenshot sir.")
        pyautogui.press('prtsc')


    elif 'show start' in query:
        speak("Opening the start menu sir.")
        press('win')

    elif 'open setting' in query:
        speak("Opening the settings window sir.")
        press_and_release('win+i')

    elif 'open search' in query:
        speak("Opening the search bar sir.")
        press_and_release('win+s')

    # elif 'take a screenshot' in query:
    #     try:
    #         speak("Taking a screenshot.")
    #         # Generate a unique file name
    #         timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    #         file_name = f"screenshot_{timestamp}.png"

    #         # Save the screenshot in the current directory
    #         pyautogui.screenshot().save(file_name)
    #         speak(f"Screenshot saved as {file_name} in the current directory.")
    #         print(f"Screenshot saved as {file_name}")
    #     except Exception as e:
    #         print(f"Error while taking a screenshot: {e}")
    #         speak("An error occurred while taking the screenshot.")


    elif 'restore windows' in query:
        speak("Restoring all minimized windows.")
        press_and_release('win+shift+m')

    elif 'start recording' in query:
        speak("Starting screen recording.")
        press_and_release('win+alt+r')

    elif 'stop recording' in query:
        speak("Stopping screen recording.")
        press_and_release('win+alt+r')
    else:
        speak("Sorry, I didn't understand the command.")



##################################################################################################################
