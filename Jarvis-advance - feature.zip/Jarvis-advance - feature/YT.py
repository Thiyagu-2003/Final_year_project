import pygetwindow as gw
import pyautogui
from time import sleep
import pyttsx3


# Initialize pyttsx3 engine
engine = pyttsx3.init()
engine.setProperty('rate', 175)  # Set speaking speed
engine.setProperty('voice', engine.getProperty('voices')[1].id)  # Set female voice (optional)

def speak(text):
    """Speak the given text."""
    engine.say(text)
    engine.runAndWait()


def YouTubeAuto(command):
    # Focus the browser window (replace 'YouTube' with the correct browser title if needed)
    windows = gw.getWindowsWithTitle('YouTube')
    if windows:
        windows[0].activate()  # Activate the first YouTube window found
    else:
        print("YouTube is not open or not focused.")
        return  # Exit if YouTube is not open or found

    sleep(0.5)  # Allow time for the window to activate

    query = str(command).lower()
    
    # Pause or Resume the video
    if 'pause' in query or 'pass' in query:
        pyautogui.press('space')  # Space key to pause or resume the video
        print("Video Paused sir")
        speak("Video Paused sir")

    elif 'resume' in query or 'resume' in query:
        pyautogui.press('space')  # Space key to pause or resume the video
        print("Video Resumed sir")
        speak("Video Resumed sir")

    # Fullscreen the video
    elif 'full screen' in query or 'fullscreen' in query:
        pyautogui.press('f')  # 'f' key for fullscreen
        print(" playing Video in Fullscreened sir")
        speak(" playing Video in Fullscreened sir")

    # Film Screen (Theater Mode)
    elif 'film screen' in query or 'flimscreen' in query:
        pyautogui.press('t')  # 't' key for theater mode
        print("playing Video in flimscreen sir")
        speak("playing Video in flimscreen sir")

    # Skip Forward
    elif 'skip' in query:
        pyautogui.press('l')  # 'l' key to skip 10 seconds forward
        print("Video skipped forward 10seconds sir")
        speak("Video skipped forward 10seconds sir")

    # Skip Backward
    elif 'back' in query:
        pyautogui.press('j')  # 'j' key to skip 10 seconds backward
        print("Video skipped backward sir")
        speak("Video skipped backward sir")

    # # Increase Volume
    # elif 'increase volume' in query or 'volume up' in query:
    #     pyautogui.press('volumeup')  # 'volumeup' key
    #     print(" increased Video volume sir")
    #     speak(" increased Video volume sir")


    # Increase Volume
    elif 'volume up' in query:
        pyautogui.press('volumeup')  # 'volumeup' key
        print(" increased Video volume sir")
        speak(" increased Video volume by 2 percent sir")

    # # Decrease Volume
    # elif 'decrease volume' in query or 'volume down' in query:
    #     pyautogui.press('volumedown')  # 'volumedown' key
    #     print("decreased Video volume sir")
    #     speak("decreased Video volume sir")

    # Decrease Volume
    elif 'volume down' in query:
        pyautogui.press('volumedown')  # 'volumedown' key
        print("decreased Video volume sir")
        speak("decreased Video volume by 2 percent sir")

    # Max Volume
    elif 'max volume' in query:
        for _ in range(20):  # Increase volume multiple times to max
            pyautogui.press('volumeup')
            print("maxed Video volume sir")
            speak("volume increased to its max level sir")


    # Mute
    elif 'mute' in query:
        pyautogui.press('volumemute')  # Mute the volume
        print("muted the video sir")
        speak("muted the video sir")

    # Unmute
    elif 'unmute' in query:
        pyautogui.press('volumemute')  # unmute the volume
        print("unmuted the video sir")
        speak("unmuted the video sir")

    # Next Video
    elif 'next' in query:
        pyautogui.hotkey('shift', 'n')  # 'shift + n' for next video
        print("playing next Video sir")
        speak("playing next Video sir")

    # Previous Video
    elif 'previous' in query:
        pyautogui.hotkey('shift', 'p')  # 'shift + p' for previous video
        print("playing previous Video sir")
        speak("playing previous Video sir")








######### features to add




# Open camera and capture a  photo using voice command and close camera using voice command features in python for pc 


# On/off wifi bluetooth increase and brightness , volume by incrementing and decrementing by 25% of 100% in python using voice command features for pc

# Creating a folder rename delete a folder using voice command features in python for pc

# ######### prompt #######
# i created a new file and named it as "on_off.py" and saved the code there ___ full code__ i need to call the function in my main jarvis code in elif statment 