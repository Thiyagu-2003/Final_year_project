import React from 'react';
import { useVoiceCommands } from '../hooks/useVoiceCommands';
import { VoiceCommandToggle } from '../components/VoiceCommandToggle';
import { ExerciseCard } from '../components/ExerciseCard';
import { ExerciseFilters } from '../components/ExerciseFilters';
import { fetchExercises } from '../services/exerciseApi';
import { Exercise, ExerciseFilters as FilterTypes } from '../types/exercise';

export function Workouts() {
  const [exercises, setExercises] = React.useState<Exercise[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [activeExercise, setActiveExercise] = React.useState<number | null>(null);
  const [expandedExercise, setExpandedExercise] = React.useState<string | null>(null);
  const [voiceEnabled, setVoiceEnabled] = React.useState(false);
  const [isListening, setIsListening] = React.useState(false);

  const { isSupported } = useVoiceCommands({
    onStart: () => activeExercise === null && exercises.length > 0 && startExercise(0),
    onNext: () => activeExercise !== null && nextExercise(),
    onPause: () => activeExercise !== null && pauseExercise(),
    onResume: () => activeExercise !== null && resumeExercise(),
    onStop: () => activeExercise !== null && stopExercise(),
  });

  const loadExercises = async (filters: FilterTypes) => {
    setLoading(true);
    try {
      const data = await fetchExercises(filters);
      setExercises(data);
    } catch (error) {
      console.error('Error loading exercises:', error);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    loadExercises({ muscle: 'all', difficulty: 'all', equipment: 'all' });
  }, []);

  const startExercise = (index: number) => {
    setActiveExercise(index);
    speak(`Starting ${exercises[index].name}`);
  };

  const nextExercise = () => {
    if (activeExercise !== null && activeExercise < exercises.length - 1) {
      setActiveExercise(activeExercise + 1);
      speak(`Next exercise: ${exercises[activeExercise + 1].name}`);
    }
  };

  const pauseExercise = () => {
    speak('Exercise paused');
  };

  const resumeExercise = () => {
    speak('Exercise resumed');
  };

  const stopExercise = () => {
    setActiveExercise(null);
    speak('Workout ended');
  };

  const speak = (text: string) => {
    if (voiceEnabled) {
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utterance);
    }
  };

  const toggleVoiceCommands = () => {
    setVoiceEnabled(!voiceEnabled);
    setIsListening(!voiceEnabled);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Exercise Library</h1>
        {isSupported && (
          <VoiceCommandToggle
            isEnabled={voiceEnabled}
            isListening={isListening}
            onToggle={toggleVoiceCommands}
          />
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <ExerciseFilters
            onFilterChange={(filters) => loadExercises(filters)}
          />
        </div>

        <div className="lg:col-span-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {exercises.map((exercise, index) => (
              <ExerciseCard
                key={exercise.id}
                exercise={exercise}
                onStart={() => startExercise(index)}
                expanded={expandedExercise === exercise.id}
                onToggleExpand={() => setExpandedExercise(
                  expandedExercise === exercise.id ? null : exercise.id
                )}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}