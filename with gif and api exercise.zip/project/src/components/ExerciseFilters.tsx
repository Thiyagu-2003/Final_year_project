import React from 'react';
import { Filter } from 'lucide-react';
import { cn } from '../lib/utils';

interface ExerciseFiltersProps {
  onFilterChange: (filters: { muscle: string; difficulty: string; equipment: string }) => void;
}

export function ExerciseFilters({ onFilterChange }: ExerciseFiltersProps) {
  const [muscle, setMuscle] = React.useState('all');
  const [difficulty, setDifficulty] = React.useState('all');
  const [equipment, setEquipment] = React.useState('all');

  const muscles = ['all', 'chest', 'back', 'shoulders', 'legs', 'arms', 'core'];
  const difficulties = ['all', 'beginner', 'intermediate', 'advanced'];
  const equipments = ['all', 'bodyweight', 'dumbbell', 'barbell', 'machine', 'cable', 'kettlebell'];

  const handleFilterChange = (type: string, value: string) => {
    switch (type) {
      case 'muscle':
        setMuscle(value);
        break;
      case 'difficulty':
        setDifficulty(value);
        break;
      case 'equipment':
        setEquipment(value);
        break;
    }

    onFilterChange({
      muscle: type === 'muscle' ? value : muscle,
      difficulty: type === 'difficulty' ? value : difficulty,
      equipment: type === 'equipment' ? value : equipment,
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg space-y-6">
      <div className="flex items-center space-x-2 mb-4">
        <Filter className="h-5 w-5 text-blue-600" />
        <h2 className="text-lg font-semibold">Filters</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Muscle Group</label>
          <div className="flex flex-wrap gap-2">
            {muscles.map((m) => (
              <button
                key={m}
                onClick={() => handleFilterChange('muscle', m)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm transition-colors",
                  muscle === m
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                )}
              >
                {m.charAt(0).toUpperCase() + m.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Difficulty</label>
          <div className="flex flex-wrap gap-2">
            {difficulties.map((d) => (
              <button
                key={d}
                onClick={() => handleFilterChange('difficulty', d)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm transition-colors",
                  difficulty === d
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                )}
              >
                {d.charAt(0).toUpperCase() + d.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Equipment</label>
          <div className="flex flex-wrap gap-2">
            {equipments.map((e) => (
              <button
                key={e}
                onClick={() => handleFilterChange('equipment', e)}
                className={cn(
                  "px-3 py-1 rounded-full text-sm transition-colors",
                  equipment === e
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                )}
              >
                {e.charAt(0).toUpperCase() + e.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}