import axios from 'axios';
import { Exercise } from '../types/exercise';

const EXERCISE_API_URL = 'https://exercisedb.p.rapidapi.com';
const GIPHY_API_KEY = '3J2mekM2hGZe6Lk7n9eLF6CIVAm96dzt';
const RAPID_API_KEY = '90c3a63e1amsh1f979220e825a91p101626jsn5bfbb9adaa34';

export async function fetchExercises(filters: {
  muscle?: string;
  difficulty?: string;
  equipment?: string;
}): Promise<Exercise[]> {
  try {
    const response = await axios.get(`${EXERCISE_API_URL}/exercises`, {
      headers: {
        'X-RapidAPI-Key': RAPID_API_KEY,
        'X-RapidAPI-Host': 'exercisedb.p.rapidapi.com'
      },
      params: filters
    });

    return response.data.map((exercise: any) => ({
      id: exercise.id,
      name: exercise.name,
      type: exercise.type,
      muscle: exercise.muscle,
      equipment: exercise.equipment,
      difficulty: exercise.difficulty,
      instructions: exercise.instructions,
      gifUrl: exercise.gifUrl,
      calories: Math.floor(Math.random() * 200) + 100, // Example calculation
      sets: 3,
      reps: 12,
      variations: [],
      safetyTips: [],
      commonMistakes: []
    }));
  } catch (error) {
    console.error('Error fetching exercises:', error);
    return [];
  }
}

export async function searchGifs(query: string): Promise<string[]> {
  try {
    const response = await axios.get(`https://api.giphy.com/v1/gifs/search`, {
      params: {
        api_key: GIPHY_API_KEY,
        q: query,
        limit: 5
      }
    });

    return response.data.data.map((gif: any) => gif.images.original.url);
  } catch (error) {
    console.error('Error fetching GIFs:', error);
    return [];
  }
}