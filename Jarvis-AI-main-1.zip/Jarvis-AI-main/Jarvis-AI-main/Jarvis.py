# from sqlite3 import Date
# from typing_extensions import Self
# from numpy import place
# import speedtest
# from jmespath import search
# import pyttsx3  # pip install pyttsx3
# import speech_recognition as sr  # pip install speechRecognition
# import datetime
# import wikipedia  # pip install wikipedia
# import webbrowser
# import pywhatkit
# import pyjokes
# import os
# import wolframalpha
# from requests import get, request
# import sys
# import requests
# from bs4 import BeautifulSoup
# from playsound import playsound
# from pywikihow import search_wikihow
# from keyboard import press_and_release
# from keyboard import press 
# from PyQt5 import QtWidgets, QtCore, QtGui
# from PyQt5.QtCore import QTimer, QTime, QDate, Qt
# from PyQt5.QtGui import QMovie
# from PyQt5.QtCore import *
# from PyQt5.QtGui import *
# from PyQt5.QtWidgets import *
# from PyQt5.uic import loadUiType
# # from Features import YouTubeAuto
# from jarvisUi import Ui_jarvisUi
# import psutil
# from sympy import sympify, SympifyError
# from utils import GoogleMap
# from YT import YouTubeAuto

# # Use GoogleMap or YouTubeAuto as needed in the main program


# # Initialize the voice engine
# engine = pyttsx3.init('sapi5')
# voices = engine.getProperty('voices')
# engine.setProperty('voice', voices[1].id)
# engine.setProperty('rate', 175)


# def speak(audio):
#     engine.say(audio)
#     engine.runAndWait()


# def startup():
#     speak("All systems have been activated")


# def computational_intelligence(question):
#     try:
#         client = wolframalpha.Client('4H2PW2-3JYYGVHJQ6')
#         answer = client.query(question)
#         answer = next(answer.results).text
#         print(answer)
#         return answer
#     except:
#         speak("Sorry sir, I couldn't fetch your question's answer. Please try again.")
#         return None


# def wishMe():
#     hour = int(datetime.datetime.now().hour)
#     if hour >= 0 and hour < 12:
#         speak("Good morning sir!")
#     elif hour >= 12 and hour < 18:
#         speak("Good afternoon sir!")
#     else:
#         speak("Good evening sir!")
#     speak("Please tell me how may I help you")


# def GoogleMaps(place):
#     # Opens a location in Google Maps
#     url = f"https://www.google.com/maps/place/{place.strip().replace(' ', '+')}"
#     webbrowser.open(url)


# class MainThread(QThread):
#     def __init__(self):
#         super(MainThread, self).__init__()

#     def run(self):
#         self.TaskExecution()

#     def takeCommand(self):
#         r = sr.Recognizer()
#         with sr.Microphone() as source:
#             print("Listening...")
#             r.pause_threshold = 1
#             audio = r.listen(source, 0, 4)

#         try:
#             print("Recognizing...")
#             self.query = r.recognize_google(audio, language='en-us')
#             print(f"User said: {self.query}\n")
#         except Exception as e:
#             print("Say that again please...")
#             return "None"
#         return self.query

#     def TaskExecution(self):
#         startup()
#         wishMe()
#         while True:
#             self.query = self.takeCommand().lower()

#             if 'tell me about' in self.query:
#                 speak('Searching Wikipedia...please wait')
#                 self.query = self.query.replace("wikipedia", "")
#                 results = wikipedia.summary(self.query, sentences=2)
#                 speak("Internet says...")
#                 print(results)
#                 speak(results)

#             # elif "calculate" in self.query or "what is" in self.query:
#             #     try:
#             #         # Extract the query, assuming it's already processed to remove the keywords
#             #         question = self.query.replace("calculate", "").replace("what is", "").strip()
#             #         # Evaluate the mathematical expression
#             #         answer = eval(question)
#             #         # Speak out the result
#             #         speak(f"The answer is {answer}")
#             #     except Exception as e:
#             #         speak("I couldn't perform the calculation. Please try again with a valid mathematical expression.")
   

#             elif 'open youtube' in self.query:
#                 webbrowser.open("youtube.com")
            

#             elif "calculate" in self.query or "what is" in self.query or "multiply" in self.query or "times" in self.query:
#                 try:
#                     # Extract the query, assuming it's already processed to remove keywords
#                     question = self.query.replace("calculate", "").replace("what is", "").replace("multiply", "").replace("times", "").strip()
#                     # Safely parse the mathematical expression
#                     expression = sympify(question)
        
#                     # Evaluate the expression
#                     result = expression.evalf()
        
#                     # Format the result to avoid long decimals:
#                     # If the result is a whole number, convert to integer
#                     if float(result).is_integer():
#                         answer = int(result)  # Convert to an integer
#                     else:
#                         answer = round(float(result), 6)  # Round non-integers to 6 decimal places
#                     # Speak out the result
#                     speak(f"The answer is {answer}")
#                     #print(answer)
#                 except SympifyError:
#                     speak("I couldn't understand the mathematical expression. Please try again with a valid one.")
#                 except Exception as e:
#                     speak("An error occurred while performing the calculation. Please try again.")



            


#             elif 'open google' in self.query:
#                 webbrowser.open("google.com")

#             # elif 'where is' in self.query:
#             #     Place = self.query.lower().replace('where is', '').replace('cortana', '').strip()
#             #     if not Place:
#             #         speak("I couldn't understand the location. Please try again.")
#             #     else:
#             #         speak(f"Searching for {Place} on Google Maps.")
#             #         GoogleMaps(Place)
    

#             elif 'current temperature' in self.query:
#                 search = "temperature in my current location"
#                 url = f"https://www.google.com/search?q={search}"
#                 r = requests.get(url)
#                 data = BeautifulSoup(r.text, "html.parser")
#                 temp = data.find("div", class_="BNeawe").text
#                 speak(f'The current temperature in your location is {temp}')

#             elif 'where is' in self.query.lower():
#                 Place = self.query.lower().replace('where is', '').replace('cortana', '').strip()
#                 if not Place:
#                     speak("I couldn't understand the location. Please try again.")
#                 else:
#                     speak(f"Searching for {Place} on Google Maps.")
#                     # Open Google Maps with the specific query
#                     import webbrowser
#                     webbrowser.open(f"https://www.google.com/maps/search/{Place}")


#             elif 'shutup' in self.query or 'exit' in self.query:
#                 speak("Shutting down. Goodbye, sir.")
#                 sys.exit()
        
            
 
#             elif 'play' in self.query:
#                 speak('Surfing the browser.... Hold on sir')
#                 self.query = self.query.replace('play', '')
#                 pywhatkit.playonyt(self.query)
#                 speak('Enjoy the music')

#             elif any(keyword in self.query for keyword in ['pause', 'resume', 'mute', 'unmute', 'next', 'previous', 'increase','decrease', 'back', 'skip','fullscreen', 'filmscreen']):
#                 command = self.query
#                 speak(f"Performing the {command} action.")
#                 YouTubeAuto(command)

#             elif 'joke' in self.query:
#                 speak(pyjokes.get_joke())

#             elif "ip address" in self.query:
#                 ip = get("https://api.ipify.org").text
#                 speak(f'Your current IP address is {ip}')

#             elif 'time' in self.query or 'date' in self.query:
#                 now = datetime.datetime.now()
    
#                 if 'time' in self.query:
#                     current_time = now.strftime("%I:%M %p")  # Format: 12-hour clock with AM/PM
#                     speak(f"The current time is {current_time}")
    
#                 if 'date' in self.query:
#                     current_date = now.strftime("%A, %B %d, %Y")  # Format: Full weekday, month, day, year
#                     speak(f"Today's date is {current_date}")

        

            


# startExecution = MainThread()


# class Main(QMainWindow):
#     def __init__(self):
#         super().__init__()
#         self.ui = Ui_jarvisUi()
#         self.ui.setupUi(self)
#         self.ui.pushButton.clicked.connect(self.startTask)
#         self.ui.pushButton_2.clicked.connect(self.close)

#     def __del__(self):
#         sys.stdout = sys.__stdout__

#     def startTask(self):
#         self.ui.movie = QtGui.QMovie(".\\Material/new.gif")
#         self.ui.label_2.setMovie(self.ui.movie)
#         self.ui.movie.start()
#         self.ui.movie = QtGui.QMovie(".\\Material/path.gif")
#         self.ui.label_3.setMovie(self.ui.movie)
#         self.ui.movie.start()
#         self.ui.movie = QtGui.QMovie(".\\Material/logo.gif")
#         self.ui.label_5.setMovie(self.ui.movie)
#         self.ui.movie.start()
#         timer = QTimer(self)
#         timer.timeout.connect(self.showTime)
#         timer.start(1000)
#         startExecution.start()

#     def showTime(self):
#         current_time = QTime.currentTime()
#         current_date = QDate.currentDate()
#         label_time = current_time.toString('hh:mm:ss')
#         label_date = current_date.toString(Qt.ISODate)
#         self.ui.textBrowser.setText(label_date)
#         self.ui.textBrowser_2.setText(label_time)


# app = QApplication(sys.argv)
# jarvis = Main()
# jarvis.show()
# exit(app.exec_())




from sqlite3 import Date
import pyttsx3  # pip install pyttsx3
import speech_recognition as sr  # pip install speechRecognition
import datetime
import wikipedia  # pip install wikipedia
import webbrowser
import pywhatkit
import pyjokes
import os
import wolframalpha
from requests import get
import sys
import requests
from bs4 import BeautifulSoup
from playsound import playsound
from pywikihow import search_wikihow
from keyboard import press, press_and_release
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QTimer, QTime, QDate, Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtWidgets import QMainWindow, QApplication
from sympy import sympify, SympifyError
from jarvisUi import Ui_jarvisUi
from YT import YouTubeAuto
import wikipediaapi
from WindowsAuto import WindowsAuto



# Initialize pyttsx3 engine for voice
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)
engine.setProperty('rate', 175)


# Speak function
def speak(audio):
    engine.say(audio)
    engine.runAndWait()


# Startup
def startup():
    speak("All systems have been activated.")


# WolframAlpha computational intelligence
def computational_intelligence(question):
    try:
        client = wolframalpha.Client('4H2PW2-3JYYGVHJQ6')  # Add your WolframAlpha API Key
        answer = client.query(question)
        answer = next(answer.results).text
        print(answer)
        return answer
    except:
        speak("Sorry sir, I couldn't fetch the answer. Please try again.")
        return None


# Wish the user
def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good morning sir!")
    elif hour >= 12 and hour < 18:
        speak("Good afternoon sir!")
    else:
        speak("Good evening sir!")
    speak("Please tell me how may I help you.")

   # WIKIPEDIA FUNCTION

def tell_me_about(self):
    try:
        # Removing the trigger phrase
        speak('Searching Wikipedia...please wait')
        self.query = self.query.replace("tell me about", "").strip()
        print(f"Query: {self.query}")

        # Searching for the topic
        results = wikipedia.summary(self.query, sentences=2)
        
        # Speaking the result
        speak("Internet says...")
        print(results)
        speak(results)

    except wikipedia.DisambiguationError as e:
        # Handle multiple results found for the query
        speak("There are multiple topics matching your query. Please be more specific.")
        print(f"DisambiguationError: {e.options}")

    except wikipedia.PageError:
        # Handle the case where no results are found
        speak("Sorry, I could not find any information on Wikipedia for that topic.")
        print("PageError: No results found for the query.")

    except Exception as e:
        # Catch all other exceptions
        speak("Sorry, an error occurred while searching Wikipedia.")
        print(f"Error: {e}")




# Main Task Execution Class
class MainThread(QtCore.QThread):
    def __init__(self):
        super(MainThread, self).__init__()

    def run(self):
        self.TaskExecution()

    def takeCommand(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            r.pause_threshold = 1
            audio = r.listen(source, 0, 4)

        try:
            print("Recognizing...")
            self.query = r.recognize_google(audio, language='en-us')
            print(f"User said: {self.query}\n")
        except Exception as e:
            print("Say that again please...")

            return "None"
        return self.query

    def TaskExecution(self):
        startup()
        wishMe()
        while True:
            self.query = self.takeCommand().lower()

            # if 'tell me about' in self.query:
            #     speak('Searching Wikipedia...please wait')
            #     self.query = self.query.replace("tell me about", "")
            #     from bs4 import BeautifulSoup
            #     # This is just an example of how to use BeautifulSoup to parse HTML
            #     html_content = "<html><body><h1>Some HTML content</h1></body></html>"
            #     soup = BeautifulSoup(html_content, "html.parser")
            #     print(soup.prettify())
            #     results = wikipedia.summary(self.query, sentences=2)
            #     speak("Internet says...")
            #     print(results)
            #     speak(results)

            if 'tell me about' in self.query:
                tell_me_about(self)

            #    speak('Searching Wikipedia...please wait')
            #    self.query = self.query.replace("tell me about", "").strip()
            #    results = wikipedia.summary(self.query, sentences=2)
            #    speak("Internet says...")
            #    print(results)
            #    speak(results)

            elif 'open youtube' in self.query:
                webbrowser.open("youtube.com")

            elif "calculate" in self.query or "what is" in self.query or "multiply" in self.query or "times" in self.query:
                try:
                    question = self.query.replace("calculate", "").replace("what is", "").replace("multiply", "").replace("times", "").strip()
                    expression = sympify(question)
                    result = expression.evalf()

                    if float(result).is_integer():
                        answer = int(result)
                    else:
                        answer = round(float(result), 6)
                    speak(f"The answer is {answer}")
                except SympifyError:
                    speak("I couldn't understand the mathematical expression. Please try again.")
                except Exception as e:
                    speak("An error occurred while performing the calculation. Please try again.")

            elif 'play' in self.query:
                speak('Surfing the browser.... Hold on sir')
                self.query = self.query.replace('play', '')
                pywhatkit.playonyt(self.query)
                speak('Enjoy the music')

            elif any(keyword in self.query for keyword in ['pause', 'resume', 'mute', 'unmute', 'next', 'previous', 'increase', 'decrease', 'back', 'skip', 'fullscreen', 'filmscreen', 'volume up', 'volume down', 'max volume']):
                command = self.query
                YouTubeAuto(command)
                speak(f"Performing the {command} action.")

            elif 'joke' in self.query:
                speak(pyjokes.get_joke())

            elif 'ip address' in self.query:
                ip = get("https://api.ipify.org").text
                speak(f'Your current IP address is {ip}')

            elif 'time' in self.query or 'date' in self.query:
                now = datetime.datetime.now()
                if 'time' in self.query:
                    current_time = now.strftime("%I:%M %p")
                    speak(f"The current time is {current_time}")
                if 'date' in self.query:
                    current_date = now.strftime("%A, %B %d, %Y")
                    speak(f"Today's date is {current_date}")


            elif 'where is' in self.query.lower():
                Place = self.query.lower().replace('where is', '').replace('cortana', '').strip()
                if not Place:
                    speak("I couldn't understand the location. Please try again.")
                else:
                    speak(f"Searching for {Place} on Google Maps.")
                    # Open Google Maps with the specific query
                    import webbrowser
                    webbrowser.open(f"https://www.google.com/maps/search/{Place}")

            elif 'open google' in self.query:
                webbrowser.open("google.com")

            
            elif 'current temperature' in self.query:
                search = "temperature in my current location"
                url = f"https://www.google.com/search?q={search}"
                r = requests.get(url)
                data = BeautifulSoup(r.text, "html.parser")
                temp = data.find("div", class_="BNeawe").text
                speak(f'The current temperature in your location is {temp}')


            elif 'windows' in self.query or any(keyword in self.query for keyword in ['home screen', 'minimize', 'show start', 'open setting','open search', 'screen shot', 'restore windows','start recording', 'stop recording']):
                WindowsAuto(self.query)




            elif 'shutup' in self.query or 'exit' in self.query:
                speak("Shutting down. Goodbye, sir.")
                sys.exit()


# Main Class for GUI
class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_jarvisUi()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.startTask)
        self.ui.pushButton_2.clicked.connect(self.close)

    def __del__(self):
        sys.stdout = sys.__stdout__

    def startTask(self):
        self.ui.movie = QtGui.QMovie(".\\Material/new.gif")
        self.ui.label_2.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie(".\\Material/path.gif")
        self.ui.label_3.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie(".\\Material/logo.gif")
        self.ui.label_5.setMovie(self.ui.movie)
        self.ui.movie.start()
        timer = QTimer(self)
        timer.timeout.connect(self.showTime)
        timer.start(1000)
        startExecution.start()

    def showTime(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        label_time = current_time.toString('hh:mm:ss')
        label_date = current_date.toString(Qt.ISODate)
        self.ui.textBrowser.setText(label_date)
        self.ui.textBrowser_2.setText(label_time)


startExecution = MainThread()

# Start the Application
app = QApplication(sys.argv)
jarvis = Main()
jarvis.show()
exit(app.exec_())
