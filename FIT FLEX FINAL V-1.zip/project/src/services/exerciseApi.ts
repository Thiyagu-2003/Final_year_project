import axios from 'axios';
import { Exercise } from '../types/exercise';

const EXERCISE_API_URL = 'https://exercisedb.p.rapidapi.com';
const GIPHY_API_KEY = '3J2mekM2hGZe6Lk7n9eLF6CIVAm96dzt';
const RAPID_API_KEY = '90c3a63e1amsh1f979220e825a91p101626jsn5bfbb9adaa34';

// Common safety tips for different exercise types
const commonSafetyTips = {
  strength: [
    'Warm up properly before starting',
    'Maintain proper form throughout the movement',
    'Breathe steadily and don\'t hold your breath',
    'Start with lighter weights to perfect form',
  ],
  cardio: [
    'Stay hydrated throughout the workout',
    'Monitor your heart rate',
    'Wear appropriate footwear',
    'Stop if you feel dizzy or lightheaded',
  ],
  flexibility: [
    'Don\'t bounce while stretching',
    'Stretch to the point of tension, not pain',
    'Hold stretches for 15-30 seconds',
    'Breathe deeply and regularly',
  ],
};

// Common mistakes for different exercise types
const commonMistakes = {
  strength: [
    'Using momentum instead of controlled movement',
    'Rushing through repetitions',
    'Not maintaining proper posture',
    'Lifting too heavy too soon',
  ],
  cardio: [
    'Not pacing yourself properly',
    'Poor breathing technique',
    'Overstriding while running',
    'Skipping warm-up',
  ],
  flexibility: [
    'Stretching cold muscles',
    'Forcing the stretch too far',
    'Not holding stretches long enough',
    'Incorrect alignment',
  ],
};

// Exercise variations for different types
const exerciseVariations = {
  pushup: [
    'Diamond Push-ups',
    'Wide-grip Push-ups',
    'Decline Push-ups',
    'Plyometric Push-ups',
  ],
  squat: [
    'Jump Squats',
    'Sumo Squats',
    'Bulgarian Split Squats',
    'Pistol Squats',
  ],
  plank: [
    'Side Plank',
    'Plank with Shoulder Taps',
    'Walking Plank',
    'Reverse Plank',
  ],
};

function getExerciseType(exercise: any): 'strength' | 'cardio' | 'flexibility' {
  const cardioKeywords = ['running', 'jumping', 'cardio', 'burpee'];
  const flexibilityKeywords = ['stretch', 'yoga', 'mobility', 'flexibility'];
  
  const name = exercise.name.toLowerCase();
  if (cardioKeywords.some(keyword => name.includes(keyword))) return 'cardio';
  if (flexibilityKeywords.some(keyword => name.includes(keyword))) return 'flexibility';
  return 'strength';
}

function calculateCalories(exercise: any): number {
  const baseCalories = {
    strength: 150,
    cardio: 200,
    flexibility: 100,
  };
  
  const type = getExerciseType(exercise);
  const base = baseCalories[type];
  
  // Add some variation
  return Math.floor(base + (Math.random() * 50));
}

function getExerciseVariations(exercise: any): string[] {
  const name = exercise.name.toLowerCase();
  if (name.includes('push')) return exerciseVariations.pushup;
  if (name.includes('squat')) return exerciseVariations.squat;
  if (name.includes('plank')) return exerciseVariations.plank;
  return [];
}

export async function fetchExercises(filters: {
  muscle?: string;
  difficulty?: string;
  equipment?: string;
}): Promise<Exercise[]> {
  try {
    const response = await axios.get(`${EXERCISE_API_URL}/exercises`, {
      headers: {
        'X-RapidAPI-Key': RAPID_API_KEY,
        'X-RapidAPI-Host': 'exercisedb.p.rapidapi.com'
      },
      params: {
        ...filters,
        limit: 50 // Increased limit for more exercises
      }
    });

    return response.data.map((exercise: any) => {
      const type = getExerciseType(exercise);
      return {
        id: exercise.id,
        name: exercise.name,
        type: exercise.type,
        muscle: exercise.muscle,
        equipment: exercise.equipment,
        difficulty: exercise.difficulty || 'beginner',
        instructions: exercise.instructions || [
          'Set up in proper starting position',
          'Maintain proper form throughout the movement',
          'Control the movement during both phases',
          'Focus on muscle engagement'
        ],
        gifUrl: exercise.gifUrl,
        calories: calculateCalories(exercise),
        sets: 3,
        reps: 12,
        variations: getExerciseVariations(exercise),
        safetyTips: commonSafetyTips[type],
        commonMistakes: commonMistakes[type],
        videoUrl: null, // Could be added if available from API
        thumbnailUrl: null
      };
    });
  } catch (error) {
    console.error('Error fetching exercises:', error);
    throw error;
  }
}

export async function searchGifs(query: string): Promise<string[]> {
  try {
    const response = await axios.get(`https://api.giphy.com/v1/gifs/search`, {
      params: {
        api_key: GIPHY_API_KEY,
        q: query,
        limit: 5
      }
    });

    return response.data.data.map((gif: any) => gif.images.original.url);
  } catch (error) {
    console.error('Error fetching GIFs:', error);
    return [];
  }
}