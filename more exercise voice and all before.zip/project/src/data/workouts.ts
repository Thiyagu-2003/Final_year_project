import { WorkoutPlan } from '../types/user';

export const workoutPlans: WorkoutPlan[] = [
  {
    id: '1',
    title: 'Full Body Power',
    duration: '45 min',
    difficulty: 'Intermediate',
    image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 400,
    category: 'Full Body',
    exercises: [
      {
        name: 'Push-ups',
        sets: 3,
        reps: 12,
        restTime: 60,
        gifUrl: 'https://images.unsplash.com/photo-1544033527-b192daee1f5b?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
        instructions: ['Start in plank position', 'Lower chest to ground', 'Push back up', 'Maintain straight body']
      },
      {
        name: 'Squats',
        sets: 4,
        reps: 15,
        restTime: 60,
        gifUrl: 'https://images.unsplash.com/photo-1566241142559-40e1dab266c6?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
        instructions: ['Feet shoulder-width apart', 'Lower hips back and down', 'Keep chest up', 'Drive through heels']
      },
      {
        name: 'Dumbbell Rows',
        sets: 3,
        reps: 12,
        restTime: 60,
        gifUrl: 'https://images.unsplash.com/photo-1544033527-b192daee1f5b?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
        instructions: ['Bend over with flat back', 'Pull weight to hip', 'Control descent', 'Keep elbow close']
      }
    ]
  },
  {
    id: '2',
    title: 'Arms Blast',
    duration: '30 min',
    difficulty: 'Beginner',
    image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 300,
    category: 'Arms',
    exercises: [
      {
        name: 'Bicep Curls',
        sets: 3,
        reps: 12,
        restTime: 45,
        instructions: ['Stand straight', 'Curl weights up', 'Control descent', 'Keep elbows fixed']
      },
      {
        name: 'Tricep Extensions',
        sets: 3,
        reps: 15,
        restTime: 45,
        instructions: ['Hold weight overhead', 'Lower behind head', 'Extend arms', 'Keep elbows in']
      }
    ]
  },
  {
    id: '3',
    title: 'Core Crusher',
    duration: '20 min',
    difficulty: 'Advanced',
    image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 250,
    category: 'Core',
    exercises: [
      {
        name: 'Plank',
        sets: 3,
        reps: 60,
        restTime: 45,
        instructions: ['Forearms on ground', 'Straight body line', 'Engage core', 'Hold position']
      },
      {
        name: 'Russian Twists',
        sets: 3,
        reps: 20,
        restTime: 45,
        instructions: ['Sit with knees bent', 'Lean back slightly', 'Rotate torso', 'Keep feet lifted']
      }
    ]
  },
  {
    id: '4',
    title: 'Leg Day',
    duration: '40 min',
    difficulty: 'Intermediate',
    image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 450,
    category: 'Legs',
    exercises: [
      {
        name: 'Lunges',
        sets: 3,
        reps: 12,
        restTime: 60,
        instructions: ['Step forward', 'Lower back knee', 'Keep front knee aligned', 'Push back up']
      },
      {
        name: 'Calf Raises',
        sets: 4,
        reps: 20,
        restTime: 45,
        instructions: ['Stand on edge', 'Rise on toes', 'Lower heels', 'Control movement']
      }
    ]
  }
];