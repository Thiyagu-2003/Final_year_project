import { WorkoutPlan } from '../types/user';

export const workoutPlans: WorkoutPlan[] = [
  {
    id: '1',
    title: 'Full Body Workout',
    duration: '45 min',
    difficulty: 'Intermediate',
    image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 400,
    exercises: [
      { name: 'Push-ups', sets: 3, reps: 12, restTime: 60 },
      { name: 'Squats', sets: 4, reps: 15, restTime: 60 },
      { name: 'Dumbbell Rows', sets: 3, reps: 12, restTime: 60 },
      { name: 'Lunges', sets: 3, reps: 10, restTime: 45 },
      { name: 'Plank', sets: 3, reps: 1, restTime: 45 }
    ]
  },
  {
    id: '2',
    title: 'Upper Body Focus',
    duration: '30 min',
    difficulty: 'Beginner',
    image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 300,
    exercises: [
      { name: 'Bench Press', sets: 3, reps: 10, restTime: 60 },
      { name: 'Shoulder Press', sets: 3, reps: 12, restTime: 60 },
      { name: 'Tricep Extensions', sets: 3, reps: 15, restTime: 45 },
      { name: 'Bicep Curls', sets: 3, reps: 12, restTime: 45 }
    ]
  },
  {
    id: '3',
    title: 'Core Strength',
    duration: '20 min',
    difficulty: 'Advanced',
    image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 250,
    exercises: [
      { name: 'Crunches', sets: 3, reps: 20, restTime: 45 },
      { name: 'Russian Twists', sets: 3, reps: 30, restTime: 45 },
      { name: 'Leg Raises', sets: 3, reps: 15, restTime: 45 },
      { name: 'Mountain Climbers', sets: 3, reps: 20, restTime: 30 }
    ]
  },
  {
    id: '4',
    title: 'Lower Body Power',
    duration: '40 min',
    difficulty: 'Intermediate',
    image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 450,
    exercises: [
      { name: 'Deadlifts', sets: 4, reps: 8, restTime: 90 },
      { name: 'Bulgarian Split Squats', sets: 3, reps: 12, restTime: 60 },
      { name: 'Calf Raises', sets: 4, reps: 15, restTime: 45 },
      { name: 'Hip Thrusts', sets: 3, reps: 12, restTime: 60 }
    ]
  },
  {
    id: '5',
    title: 'HIIT Cardio',
    duration: '25 min',
    difficulty: 'Advanced',
    image: 'https://images.unsplash.com/photo-1599058945522-28d584b6f0ff?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    calories: 350,
    exercises: [
      { name: 'Burpees', sets: 4, reps: 10, restTime: 30 },
      { name: 'Jump Rope', sets: 4, reps: 50, restTime: 30 },
      { name: 'High Knees', sets: 4, reps: 30, restTime: 30 },
      { name: 'Box Jumps', sets: 4, reps: 12, restTime: 30 }
    ]
  }
];