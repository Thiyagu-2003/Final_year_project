import React from 'react';
import { Play, Clock, BarChart, Dumbbell } from 'lucide-react';
import { workoutPlans } from '../data/workouts';

export function Workouts() {
  const [selectedWorkout, setSelectedWorkout] = React.useState(null);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Workout Plans</h1>
      
      {selectedWorkout ? (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold">{selectedWorkout.title}</h2>
            <button
              onClick={() => setSelectedWorkout(null)}
              className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
            >
              Back to Workouts
            </button>
          </div>
          
          <div className="space-y-6">
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                {selectedWorkout.duration}
              </div>
              <div className="flex items-center">
                <BarChart className="h-4 w-4 mr-1" />
                {selectedWorkout.difficulty}
              </div>
              <div className="flex items-center">
                <Dumbbell className="h-4 w-4 mr-1" />
                {selectedWorkout.calories} calories
              </div>
            </div>

            <div className="space-y-4">
              {selectedWorkout.exercises.map((exercise, index) => (
                <div key={index} className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">{exercise.name}</h3>
                  <div className="flex space-x-4 text-sm text-gray-600 dark:text-gray-400">
                    <span>{exercise.sets} sets</span>
                    <span>{exercise.reps} reps</span>
                    <span>{exercise.restTime}s rest</span>
                  </div>
                </div>
              ))}
            </div>

            <button className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors">
              <Play className="h-5 w-5" />
              <span>Start Workout</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {workoutPlans.map((workout) => (
            <div key={workout.id} className="rounded-lg overflow-hidden bg-white dark:bg-gray-800 shadow-lg">
              <img
                src={workout.image}
                alt={workout.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-xl font-semibold mb-2">{workout.title}</h3>
                <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {workout.duration}
                  </div>
                  <div className="flex items-center">
                    <BarChart className="h-4 w-4 mr-1" />
                    {workout.difficulty}
                  </div>
                </div>
                <button
                  onClick={() => setSelectedWorkout(workout)}
                  className="mt-4 w-full bg-blue-600 text-white py-2 px-4 rounded-lg flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors"
                >
                  <Play className="h-4 w-4" />
                  <span>View Workout</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}